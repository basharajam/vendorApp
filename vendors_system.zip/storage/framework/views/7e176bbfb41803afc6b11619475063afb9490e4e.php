<div class="kt-footer  kt-footer--extended  kt-grid__item" id="kt_footer">

    <div class="kt-footer__bottom">
        <div class="kt-container kt-container--fluid ">
            <div class="kt-footer__wrapper text-center">
                <div class="kt-footer__logo">
                    <div class="kt-footer__copyright text-center">

                        <a href="#" target="_blank">2020&nbsp;&copy;&nbsp; Alyaman</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/components/layout/footer.blade.php ENDPATH**/ ?>