<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column-fluid">
    <div class="container-fluid">

        <div class="card card-custom gutter-b d-flex">
            <div class="row">
                <div class="col-md-5">
                    <div class="text-center pt-15 w-100">
                        <h1 class="h2 font-weight-bolder text-dark mb-6">هل أنت بحاجة إلى مساعدة؟</h1>
                        <div class="h4 text-dark-50 font-weight-normal">ارسل طلب المساعدةالخاص بك إلى أحد الخبراء</div>
                        <div class="row d-flex justify-content-center">
                            <div class="col-md-12">
                                <span class="svg-icon svg-icon-full">
                                   <?php echo $__env->make('supplier.support.components.support_svg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-7">
                    <?php echo $__env->make('supplier.support.components.support_form',['type'=>"App\Models\Supplier"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>


        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/supplier/support/create.blade.php ENDPATH**/ ?>