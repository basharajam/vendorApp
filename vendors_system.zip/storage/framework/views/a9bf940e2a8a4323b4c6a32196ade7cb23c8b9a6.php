<h1>Variable</h1>
<?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/supplier/products/components/variable_product.blade.php ENDPATH**/ ?>