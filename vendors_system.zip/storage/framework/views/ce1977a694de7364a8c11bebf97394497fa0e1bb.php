<?php
if($product)
{
    $product_type = $product->product_type;
}
?>
<div class="row">
    <div class="col-12 mb-10" style="text-align: right">
        <h3>اختر نوع المنتج</h3>
    </div>
    <div class="col-lg-6">
        <label class="option">
            <span class="option-control">
                <span class="radio">
                    <input type="radio" name="product_type" value="simple" <?php if($product && $product_type && $product_type->term->name==\ProductTypes::SIMPLE): ?> checked="checked" <?php elseif($product!=null): ?> disabled <?php endif; ?>>
                    <span></span>
                </span>
            </span>
            <span class="option-label">
                <span class="option-head">
                    <span class="option-title">قياس واحد</span>
                    <span class="option-focus"></span>
                </span>
                <span class="option-body">some descriptoin about this type</span>
            </span>
        </label>
    </div>
    <div class="col-lg-6">
        <label class="option">
            <span class="option-control">
                <span class="radio">
                    <input type="radio" name="product_type" value="variable" <?php if($product && $product_type && $product_type->term->name==\ProductTypes::VARIABLE): ?> checked="checked" <?php elseif($product!=null): ?> disabled <?php endif; ?>>
                    <span></span>
                </span>
            </span>
            <span class="option-label">
                <span class="option-head">
                    <span class="option-title">عدة قياسات</span>
                    <span class="option-focus"></span>
                </span>
                <span class="option-body">some descriptoin about this type</span>
            </span>
        </label>
    </div>
</div>
<?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/supplier/products/components/product_type_card.blade.php ENDPATH**/ ?>