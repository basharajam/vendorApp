<?php
$meta = [];
if($product){
    $meta = $product->meta;
}
?>
<div class="kt-portlet" id="InventoryInfo" style="diaplay:none" >
    <div class="kt-portlet__head">
        <div class="kt-portlet__head-label">
            <h3 class="kt-portlet__head-title">معلومات المحزن</h3>
        </div>
    </div>
    <div class="kt-portlet__body">
        <form action="<?php echo e(route('supplier.products.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="supplier_name" value="<?php echo e(\Auth::user()->name); ?>">
            <input type="hidden" name="post_id"  value="<?php echo e($product->ID ?? 0); ?>">
            <input type="hidden" name="post_author"  value="<?php echo e(\Auth::user()->wordpress_user->ID ?? 0); ?>">
            <input type="hidden" name="request_type" value="inventory">
            <div class="row">
                <div class="col-lg-12">
                    <div class="form-group">
                        <label class="font-size-h6 font-weight-bolder text-dark">
                            <span class="flaticon2-information" data-toggle="tooltip" data-theme="dark"  title="يشير SKU إلى وحدة حفظ المخزون ، وهو معرف فريد لكل منتج وخدمة مميزة يمكن شراؤها"></span>
                            <span class="required">*</span>
                            <span>SKU</span>
                        </label>
                        <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 <?php $__errorArgs = ['_sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="" name="_sku" value="<?php echo e(array_key_exists('_sku',$meta ) ? $meta['_sku']  :  old('_sku')); ?>" required  />
                        <?php $__errorArgs = ['_sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="fv-plugins-message-container">
                            <div  class="fv-help-block"><?php echo e($message); ?></div>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>
                <div class="col-12">
                    <div class="form-group">
                        <label class="col-form-label col-12 font-size-h6 font-weight-bolder text-dark" >
                            <span>حالة المنتج</span>
                            <span class="required">*</span>
                            <span class="flaticon2-information" data-toggle="tooltip" data-theme="dark"  title='يتحكم في ما إذا كان المنتج مدرجًا على أنه "متوفر" أو "غير متوفر".'></span>
                        </label>
                        <div class="kt-input-icon">
                            <select  class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6"
                                    id="_stock_status"
                                    name="_stock_status" required>
                                <option value="instock" <?php if(array_key_exists('_stock_status',$meta)  && $meta['_stock_status']=='instock'): ?> selected <?php endif; ?>>متوفر</option>
                                <option value="outofstock" <?php if(array_key_exists('_stock_status',$meta)  && $meta['_stock_status']=='outofstock'): ?> selected <?php endif; ?>>غير متوفر</option>
                                <option value="onbackorder" <?php if(array_key_exists('_stock_status',$meta)  && $meta['_stock_status']=='onbackorder'): ?> selected <?php endif; ?>>تحت الطلب</option>
                            </select>
                        </div>
                        <?php $__errorArgs = ['_stock_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="fv-plugins-message-container">
                            <div  class="fv-help-block"><?php echo e($message); ?></div>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-12">
                    <div class="form-group">
                        <label class="font-size-h6 font-weight-bolder text-dark">
                            <span>تباع بشكل فردي</span>
                        </label>
                        <div class="checkbox-inline">
                            <label class="checkbox">
                            <input type="checkbox"  name="_sold_individually" id="_sold_individually" value="yes" <?php if(array_key_exists('_sold_individually',$meta) && $meta['_sold_individually']=="yes"): ?> checked="checked" <?php endif; ?>>
                            <span></span>قم بتمكين هذا للسماح بشراء عنصر واحد فقط من هذا العنصر بترتيب واحد</label>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label class="font-size-h6 font-weight-bolder text-dark">
                            <span>الحد الأدنى من الكمية</span>
                            <span class="flaticon2-information" data-toggle="tooltip" data-theme="dark"  title="اختياري. قم بتعيين حد أدنى للكمية المسموح بها لكل طلب. أدخل رقمًا ، 1 أو أكبر."></span>
                        </label>
                        <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 <?php $__errorArgs = ['_wc_min_qty_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="" name="_wc_min_qty_product" value="<?php echo e(array_key_exists('_wc_min_qty_product',$meta) ?  $meta['_wc_min_qty_product'] :  old('_wc_min_qty_product')); ?>"   />
                        <?php $__errorArgs = ['_wc_min_qty_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="fv-plugins-message-container">
                            <div  class="fv-help-block"><?php echo e($message); ?></div>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label class="font-size-h6 font-weight-bolder text-dark">
                            <span>الحد الاقصى من الكمية</span>
                            <span class="flaticon2-information" data-toggle="tooltip" data-theme="dark"  title="اختياري. قم بتعيين الحد الأقصى للكمية المسموح بها لكل طلب. أدخل رقمًا ، 1 أو أكبر"></span>
                        </label>
                        <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 <?php $__errorArgs = ['_wc_max_qty_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="" name="_wc_max_qty_product" value="<?php echo e(array_key_exists('_wc_max_qty_product',$meta) ? $meta['_wc_max_qty_product'] : old('_wc_max_qty_product')); ?>"   />
                        <?php $__errorArgs = ['_wc_max_qty_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="fv-plugins-message-container">
                            <div  class="fv-help-block"><?php echo e($message); ?></div>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="form-group">
                        <label class="font-size-h6 font-weight-bolder text-dark">
                            <span>كمية بالكرتونة الواحدة</span>
                            <span class="required">*</span>
                            <span class="flaticon2-information" data-toggle="tooltip" data-theme="dark"  title="أدخل كمية كل كارتون"></span>
                        </label>
                        <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 <?php $__errorArgs = ['cartoon_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="" name="cartoon_qty" value="<?php echo e(array_key_exists('cartoon_qty',$meta) ?  $meta['cartoon_qty'] : old('cartoon_qty')); ?>"  required />
                        <?php $__errorArgs = ['cartoon_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="fv-plugins-message-container">
                            <div  class="fv-help-block"><?php echo e($message); ?></div>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="form-group">
                        <label class="font-size-h6 font-weight-bolder text-dark">
                            <span>السعر مقابل</span>
                            <span class="required">*</span>
                            <span class="flaticon2-information" data-toggle="tooltip" data-theme="dark"  title="أدخل كمية كل كارتون"></span>
                        </label>
                        <div class="kt-input-icon">
                            <select  class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6"
                                    id="price_for"
                                    name="price_for" required>
                                    <option value="box" <?php if( array_key_exists('price_for',$meta)  && $meta['price_for']=="box"): ?> selected <?php endif; ?>>علبة</option>
                                    <option value="Pcs" <?php if(array_key_exists('price_for',$meta)  && $meta['price_for']=="Pcs"): ?> selected <?php endif; ?>>قطعة</option>
                                    <option value="opp" <?php if(array_key_exists('price_for',$meta)  && $meta['price_for']=="opp"): ?> selected <?php endif; ?>>opp</option>
                                    <option value="bag" <?php if(array_key_exists('price_for',$meta)  && $meta['price_for']=="bag"): ?> selected <?php endif; ?>>كيس</option>
                                    <option value="cartoon" <?php if(array_key_exists('price_for',$meta) && $meta['price_for']=="cartoon"): ?> selected <?php endif; ?>>كرتونة</option>
                                    <option value="set" <?php if(array_key_exists('price_for',$meta)  && $meta['price_for']=="set"): ?> selected <?php endif; ?>>مجموعة</option>
                            </select>
                        </div>

                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="form-group">
                        <label class="font-size-h6 font-weight-bolder text-dark">
                            <span>الكمية للحزمة</span>
                            <span class="required">*</span>
                            <span class="flaticon2-information" data-toggle="tooltip" data-theme="dark"  title="أدخل كمية الحزمة المختارة."></span>
                        </label>
                        <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 <?php $__errorArgs = ['price_for_input'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="" name="price_for_input" value="<?php echo e($meta['price_for_input'] ??  old('price_for_input')); ?>"   />
                        <?php $__errorArgs = ['price_for_input'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="fv-plugins-message-container">
                            <div  class="fv-help-block"><?php echo e($message); ?></div>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                </div>
                <div class="col-lg-12">
                    <div class="form-group">
                        <label class="font-size-h6 font-weight-bolder text-dark">
                            <span>النماذج بالحزمة</span>
                            <span class="required">*</span>
                            <span class="flaticon2-information" data-toggle="tooltip" data-theme="dark"  title="أدخل عدد النماذج المختلطة في العبوة."></span>
                        </label>
                        <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 <?php $__errorArgs = ['mix_of_package'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="" name="mix_of_package" value="<?php echo e($meta['mix_of_package'] ?? old('mix_of_package')); ?>"   />
                        <?php $__errorArgs = ['mix_of_package'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="fv-plugins-message-container">
                            <div  class="fv-help-block"><?php echo e($message); ?></div>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>
            <div class="form-group row mt-10 mb-0">
                <div class="col-md-6 offset-md-4">
                    <button type="submit" class="btn btn-primary ">
                        حفظ
                        <span class="spinner spinner-white spinner-md mr-10 saving" style="display:none"></span>
                    </button>
                </div>
            </div>
        </div>

        </form>
    </div>
</div>
<?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/supplier/products/components/product_form/inventory_info.blade.php ENDPATH**/ ?>