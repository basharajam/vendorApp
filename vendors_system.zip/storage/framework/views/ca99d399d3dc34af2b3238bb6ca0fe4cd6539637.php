<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column-fluid">
    <div class="container-fluid">
        <div class="card card-custom">
            <!--begin::Header-->
            <div class="card-header flex-wrap border-0 pt-6 pb-0">
                <div class="card-title">
                    <h3 class="card-label font-size-h1 font-weight-bolder">
                        <?php echo e($product->post_title); ?>

                </div>
            </div>
            <!--end::Header-->
            <!--begin::Body-->
            <div class="card-body">
                <form id="product_Form" action="<?php echo e(route('supplier.products.update',$product->ID)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('supplier.products.components.product_type_card',['product'=>$product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div id="product_type_form" class="mb-10 mt-10">
                        <?php if($product->product_type!=null): ?>
                            <?php if($product->product_type->term->name == \ProductTypes::SIMPLE): ?>
                                <?php echo $__env->make('supplier.products.components.simple_product',['categories'=>$categories,'product'=>$product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        <?php endif; ?>

                    </div>
                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                حفظ
                            </button>
                        </div>
                    </div>
                </form>

            </div>
            <!--end::Body-->
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.ckeditor.com/4.13.0/standard/ckeditor.js"></script>
<script src="<?php echo e(asset('plugins/dropzone/dist/dropzone.js')); ?>"></script>
<script>
    $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();

    });
    </script>
<script>

    let add_field_component = `<?php echo view('supplier.products.components.add_field_component'); ?>`;
    $(document).on('click','#extra_fields_button',function(){
        $("#extra_fields_container").append(add_field_component)
    });
     _init_main_image_dropzone();
    _init_product_other_files_dropzone();
    editor  =  _init_ck_editor('editor');

    function _init_main_image_dropzone(){
        let product_main_image = document.getElementById('product_main_image');
                    let $dropzone =new Dropzone('#product_main_image',{
                    url:   '<?php echo e(route('supplier.storeImage')); ?>',
                    addRemoveLinks: true,
                    headers: {
                    'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                    },
                    acceptedFiles: ".png,.jpg,.gif,.bmp,.jpeg",
                    method:'POST',
                    maxFiles: 1,
                    success: function (file, response) {
                    $('#product_Form').append('<input type="hidden" name="national_id_image" value="' + response.name + '">')
                        uploadedDocumentMap[file.name] = response.name
                    },
                    removedfile: function (file) {
                        file.previewElement.remove()
                        var name = ''
                        if (typeof file.file_name !== 'undefined') {
                            name = file.file_name
                        } else {
                            name = uploadedDocumentMap[file.name]
                        }
                        $('#product_Form').find('input[name="national_id_image"][value="' + name + '"]').remove()
                    },
                    // init:function(){
                    //         let main_image = $('#national_id_image').val();
                    //         if(main_image){
                    //             var mockFile = { name: main_image.split('/ ').pop(), size: 12345, type: 'image/'+main_image.split('.').pop()};
                    //             console.log(mockFile);
                    //             this.emit('addedfile',mockFile);
                    //             this.options.thumbnail.call(this,mockFile,'/public'+main_image );
                    //             $('.dz-progress').remove();
                    //             var existingFileCount = 1; // The number of files already uploaded
                    //             this.options.maxFiles = this.options.maxFiles - existingFileCount;
                    //         }
                    // });
    }

    function _init_product_other_files_dropzone(){
        let product_other_files = document.getElementById('product_other_files');
                    let $dropzone =new Dropzone('#product_other_files',{
                    url:   '<?php echo e(route('supplier.storeImage')); ?>',
                    addRemoveLinks: true,
                    headers: {
                    'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                    },
                    acceptedFiles: ".png,.jpg,.gif,.bmp,.jpeg,.mp4",
                    method:'POST',
                    maxFiles: 10,
                    success: function (file, response) {
                    $('#product_Form').append('<input type="hidden" name="national_id_image" value="' + response.name + '">')
                        uploadedDocumentMap[file.name] = response.name
                    },
                    removedfile: function (file) {
                        file.previewElement.remove()
                        var name = ''
                        if (typeof file.file_name !== 'undefined') {
                            name = file.file_name
                        } else {
                            name = uploadedDocumentMap[file.name]
                        }
                        $('#product_Form').find('input[name="national_id_image"][value="' + name + '"]').remove()
                    },

                    });
    }
    function _init_ck_editor(element){
        return    CKEDITOR.replace( element );
    }

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/supplier/products/edit.blade.php ENDPATH**/ ?>