<?php
if($product){
    $meta = $product->meta;
}
?>
<div class="kt-portlet" id="GeneralInfo" style="diaplay:none" >
    <div class="kt-portlet__head">
        <div class="kt-portlet__head-label">
            <h3 class="kt-portlet__head-title">معلومات المنتج العامة</h3>
        </div>
    </div>
    <div class="kt-portlet__body">
        <form action="<?php echo e(route('supplier.products.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="supplier_name" value="<?php echo e(\Auth::user()->name); ?>">
            <input type="hidden" name="post_id"  value="<?php echo e($product->ID ?? 0); ?>">
            <input type="hidden" name="post_author"  value="<?php echo e(\Auth::user()->wordpress_user->ID ?? 0); ?>">
            <input type="hidden" name="request_type" value="general">

            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label class="font-size-h6 font-weight-bolder text-dark">
                            <span>السعر</span>
                            <span class="required">*</span>

                        </label>
                        <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 <?php $__errorArgs = ['_regular_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="" name="_regular_price" value="<?php echo e($meta['_regular_price'] ?? old('_regular_price')); ?>" required  />
                        <?php $__errorArgs = ['_regular_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="fv-plugins-message-container">
                            <div  class="fv-help-block"><?php echo e($message); ?></div>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label class="font-size-h6 font-weight-bolder text-dark">
                            <span>السعر بعد الحسم</span>
                            <span class="required">*</span>
                        </label>
                        <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 <?php $__errorArgs = ['_sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="" name="_sale_price" value="<?php echo e($meta['_sale_price'] ??  old('_sale_price')); ?>" required  />
                        <?php $__errorArgs = ['_sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="fv-plugins-message-container">
                            <div  class="fv-help-block"><?php echo e($message); ?></div>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label class="font-size-h6 font-weight-bolder text-dark">
                            <span>مادة المنتج</span>
                            <span class="required">*</span>
                            <span class="flaticon2-information" data-toggle="tooltip" data-theme="dark"  title="أدخل مادة المنتج"></span>
                        </label>
                        <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 <?php $__errorArgs = ['material'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="" name="material" value="<?php echo e($meta['material'] ?? old('material')); ?>" required  />
                        <?php $__errorArgs = ['material'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="fv-plugins-message-container">
                            <div  class="fv-help-block"><?php echo e($message); ?></div>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label class="font-size-h6 font-weight-bolder text-dark">
                        <span>سماكة المنتج</span>
                        <span class="flaticon2-information" data-toggle="tooltip" data-theme="dark"  title="أدخل سمك المنتج"></span>

                    </label>
                    <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 <?php $__errorArgs = ['thickness'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="" name="thickness" value="<?php echo e($meta['thickness'] ??  old('thickness')); ?>"   />
                    <?php $__errorArgs = ['thickness'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="fv-plugins-message-container">
                        <div  class="fv-help-block"><?php echo e($message); ?></div>
                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label class="font-size-h6 font-weight-bolder text-dark">
                        <span>الطباعة</span>
                        <span class="flaticon2-information" data-toggle="tooltip" data-theme="dark"  title="أدخل ألوان الطباعة"></span>

                    </label>
                    <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 <?php $__errorArgs = ['printing_single'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="" name="printing_single" value="<?php echo e($meta['printing_single'] ??  old('printing_single')); ?>"   />
                    <?php $__errorArgs = ['printing_single'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="fv-plugins-message-container">
                        <div  class="fv-help-block"><?php echo e($message); ?></div>
                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label class="font-size-h6 font-weight-bolder text-dark">
                        <span>الحجم</span>
                        <span class="required">*</span>
                        <span class="flaticon2-information" data-toggle="tooltip" data-theme="dark"  title="أدخل حجم كل منتج"></span>
                    </label>
                    <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="" name="size" value="<?php echo e($meta['size'] ?? old('size')); ?>" required  />
                    <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="fv-plugins-message-container">
                        <div  class="fv-help-block"><?php echo e($message); ?></div>
                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
            </div>

            <div class="form-group row mt-10 mb-0">
                <div class="col-md-6 offset-md-4">
                    <button type="submit" class="btn btn-primary ">
                        حفظ
                        <span class="spinner spinner-white spinner-md mr-10 saving" style="display:none"></span>
                    </button>
                </div>
            </div>
        </div>

        </form>
    </div>
</div>
<?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/supplier/products/components/product_form/general_info.blade.php ENDPATH**/ ?>