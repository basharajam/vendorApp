<?php
$meta = [];
if($product){
    $meta = $product->meta;
}
?>
<div class="kt-portlet" id="ShippingInfo" style="" >
    <div class="kt-portlet__head">
        <div class="kt-portlet__head-label">
            <h3 class="kt-portlet__head-title">معلومات الشحن</h3>
        </div>
    </div>
    <div class="kt-portlet__body">
        <form action="<?php echo e(route('supplier.products.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="supplier_name" value="<?php echo e(\Auth::user()->name); ?>">
            <input type="hidden" name="post_id"  value="<?php echo e($product->ID ?? 0); ?>">
            <input type="hidden" name="post_author"  value="<?php echo e(\Auth::user()->wordpress_user->ID ?? 0); ?>">
            <input type="hidden" name="request_type" value="shipping">

            <div class="row">
                <div class="col-lg-12">
                    <div class="form-group">
                        <label class="font-size-h6 font-weight-bolder text-dark">
                            <span>الوزن (كيلوغرام)</span>
                        </label>
                        <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 <?php $__errorArgs = ['_weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="0" name="_weight" value="<?php echo e(array_key_exists('_weight',$meta ) ? $meta['_weight']  :  old('_weight')); ?>"   />
                        <?php $__errorArgs = ['_weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="fv-plugins-message-container">
                            <div  class="fv-help-block"><?php echo e($message); ?></div>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="form-group">
                        <label class="font-size-h6 font-weight-bolder text-dark">
                            <span>الأبعاد (سم)</span>
                        </label>
                       <div class="kt-input-icon">
                           <div class="row">
                               <div class="col-4">
                                    <input id="product_length" placeholder="الطول" class="form-control form-control-solid " size="6" type="text" name="_length" value="<?php echo e(array_key_exists('_length',$meta ) ? $meta['_length']  :  old('_length')); ?>">
                               </div>
                               <div class="col-4">
                                    <input id="product_width" placeholder="عرض" class="form-control form-control-solid " size="6" type="text" name="_width" value="<?php echo e(array_key_exists('_width',$meta ) ? $meta['_width']  :  old('_width')); ?>">
                                </div>
                                <div class="col-4">
                                        <input id="product_height" placeholder="ارتفاع" class="form-control form-control-solid " size="6" type="text" name="_height" value="<?php echo e(array_key_exists('_height',$meta ) ? $meta['_height']  :  old('_height')); ?>">
                                </div>
                           </div>
                       </div>

                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="form-group">
                        <label class="font-size-h6 font-weight-bolder text-dark">
                            <span>CBM</span>
                            <span class="flaticon2-information" data-toggle="tooltip" data-theme="dark"  title="أدخل Cbm لكل كارتون."></span>

                        </label>
                        <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 <?php $__errorArgs = ['cbm_single'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="0" name="cbm_single" value="<?php echo e(array_key_exists('cbm_single',$meta ) ? $meta['cbm_single']  :  old('cbm_single')); ?>"   />
                        <?php $__errorArgs = ['cbm_single'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="fv-plugins-message-container">
                            <div  class="fv-help-block"><?php echo e($message); ?></div>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="form-group">
                        <label class="font-size-h6 font-weight-bolder text-dark">
                            <span>عدد أيام التسليم</span>
                            <span class="required">*</span>
                            <span class="flaticon2-information" data-toggle="tooltip" data-theme="dark"  title="أدخل عدد أيام التصنيع (إذا كان المنتج متوفرًا ، أدخل 0)."></span>

                        </label>
                        <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 <?php $__errorArgs = ['days_to_delivery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="0" name="days_to_delivery" value="<?php echo e(array_key_exists('days_to_delivery',$meta ) ? $meta['days_to_delivery']  :  old('days_to_delivery')); ?>" required  />
                        <?php $__errorArgs = ['days_to_delivery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="fv-plugins-message-container">
                            <div  class="fv-help-block"><?php echo e($message); ?></div>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>
            </div>

            <div class="form-group row mt-10 mb-0">
                <div class="col-md-6 offset-md-4">
                    <button type="submit" class="btn btn-primary ">
                        حفظ
                        <span class="spinner spinner-white spinner-md mr-10 saving" style="display:none"></span>
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/supplier/products/components/product_form/shipping_info.blade.php ENDPATH**/ ?>