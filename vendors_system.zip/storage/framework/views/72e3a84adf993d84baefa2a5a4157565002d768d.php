<?php $__env->startSection('content'); ?>
<h3>Supplier Dashboard</h3>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/supplier/home/index.blade.php ENDPATH**/ ?>