<?php
$product_categories = [];
if($product){
    $product_categories = $product->categories->pluck('term_taxonomy_id')->toArray();
}
?>
<form action="<?php echo e(route('supplier.products.store')); ?>" method="post">
    <div class="w-100" style="max-height: 400px; overflow-y:scroll">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="post_id"  value="<?php echo e($product->ID ?? 0); ?>">
        <input type="hidden" name="post_author"  value="<?php echo e(\Auth::user()->wordpress_user->ID ?? 0); ?>">
        <input type="hidden" name="request_type" value="categories">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!--begin::Item-->
        <div class="d-flex align-items-center mb-6" >
            <!--begin::Checkbox-->
            <label class="checkbox checkbox-lg checkbox-primary flex-shrink-0 m-0 mr-4">
                <input type="checkbox" name="product_categories[]" value="<?php echo e($category->term_taxonomy_id); ?>" <?php if(in_array($category->term_taxonomy_id,$product_categories)): ?> checked <?php endif; ?>>
                <span></span>
            </label>
            <!--end::Checkbox-->
            <!--begin::Text-->
            <div class="d-flex flex-column flex-grow-1 py-2" style="text-align: right" >
                <a href="#" class="text-dark-75 font-weight-bold text-hover-primary font-size-lg mb-1 mr-10">
                    <?php echo e($category->term->name); ?>

                </a>
            </div>
            <!--end::Text-->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!--end::Item-->
    </div>

    <div class="form-group row mt-10 mb-0">
        <div class="col-md-6 offset-md-4">
            <button type="submit" class="btn btn-primary ">
                حفظ
                <span class="spinner spinner-white spinner-md mr-10 saving" style="display:none"></span>
            </button>
        </div>
    </div>
</form>
<?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/supplier/products/components/product_form/categories_selector.blade.php ENDPATH**/ ?>