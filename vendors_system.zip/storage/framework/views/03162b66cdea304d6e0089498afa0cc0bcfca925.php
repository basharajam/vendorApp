<div id="kt_header" class="kt-header kt-grid__item kt-header--fixed " data-ktheader-minimize="on">
     <?php if (isset($component)) { $__componentOriginalee18935bde596597b413a6f3459dac0e471600da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\HeaderTopBar::class, []); ?>
<?php $component->withName('layout.header-top-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalee18935bde596597b413a6f3459dac0e471600da)): ?>
<?php $component = $__componentOriginalee18935bde596597b413a6f3459dac0e471600da; ?>
<?php unset($__componentOriginalee18935bde596597b413a6f3459dac0e471600da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalbaed28af086f680d0c2434ffe6dfc1726e190215 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\HeaderMenu::class, []); ?>
<?php $component->withName('layout.header-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalbaed28af086f680d0c2434ffe6dfc1726e190215)): ?>
<?php $component = $__componentOriginalbaed28af086f680d0c2434ffe6dfc1726e190215; ?>
<?php unset($__componentOriginalbaed28af086f680d0c2434ffe6dfc1726e190215); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>
<?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/components/layout/header.blade.php ENDPATH**/ ?>