<div class="kt-portlet__body">
    <div class="kt-widget kt-widget--user-profile-4">
        <div class="kt-widget__head">
            <div class="kt-widget__media">
                <!--Product Image-->
                <h3></h3>
            </div>
            <div class="kt-widget__content">
                <div class="kt-widget__section">
                    <h2 class="kt-widget__username font-weight-bolder" id="product_name">
                        (Attribute) إضافة سمة جديدة
                    </h2>
                </div>
            </div>
        </div>
        <div class="kt-widget__body">
           <form action="<?php echo e(route('supplier.attributes.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo $__env->make('supplier.taxonomies.components.taxonomy_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           </form>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>

</script>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/supplier/attributes/components/add_attribute_card.blade.php ENDPATH**/ ?>