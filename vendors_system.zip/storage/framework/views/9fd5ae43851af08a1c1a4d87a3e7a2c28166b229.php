<div>
    <div class="kt-header__top ">
        <div class="kt-container kt-container--fluid ">
            <!-- begin:: Brand -->
            <div class="kt-header__brand   kt-grid__item" id="kt_header_brand">
                <div class="kt-header__brand-nav">
                   <img src="/images/logo.png">
                </div>
            </div>
            <!-- end:: Brand -->
            <!-- begin:: Header Topbar -->
            <div class="kt-header__topbar">
                 <?php if (isset($component)) { $__componentOriginalf3cfe87c42561241fc99ad41cac08c8df847d73e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\HeaderUserBar::class, []); ?>
<?php $component->withName('layout.header-user-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf3cfe87c42561241fc99ad41cac08c8df847d73e)): ?>
<?php $component = $__componentOriginalf3cfe87c42561241fc99ad41cac08c8df847d73e; ?>
<?php unset($__componentOriginalf3cfe87c42561241fc99ad41cac08c8df847d73e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </div>
            <!-- end:: Header Topbar -->
        </div>
    </div>
</div>
<?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/components/layout/header-top-bar.blade.php ENDPATH**/ ?>