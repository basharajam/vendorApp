<div class="kt-portlet__body">
    <div class="kt-widget kt-widget--user-profile-4">
        <div class="kt-widget__head">
            <div class="kt-widget__media">
                <!--Product Image-->
                <h3></h3>
            </div>
            <div class="kt-widget__content">
                <div class="kt-widget__section">
                    <h2 class="kt-widget__username font-weight-bolder" id="product_name">
                      <?php switch($type):
                          case ('product_cat'): ?>
                              (category)  إضافة صنف جديد
                              <?php break; ?>
                          <?php case ('product_tag'): ?>
                               (tag) إضافة تاغ
                              <?php break; ?>
                          <?php case ('attributes'): ?>
                              (Attribute) إضافة سمة جديدة
                             <?php break; ?>
                          <?php default: ?>

                      <?php endswitch; ?>
                    </h2>
                </div>
            </div>
        </div>
        <div class="kt-widget__body">
           <form action="<?php echo e(route('supplier.taxonomies.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo $__env->make('supplier.taxonomies.components.taxonomy_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           </form>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>

</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/supplier/taxonomies/components/add_card.blade.php ENDPATH**/ ?>