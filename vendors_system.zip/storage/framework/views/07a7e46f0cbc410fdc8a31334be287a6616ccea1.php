<div class="col-12">
    <div class="form-group">
        <label class="col-form-label col-12 font-size-h6 font-weight-bolder text-dark" >
            <span><?php echo e(str_replace('pa_','',$taxonomy)); ?></span>
            <span class="required">*</span>

        </label>
        <div class="kt-input-icon d-flex justify-content-center" >
            <select  id="attributesSelectorInput"   name="taxonomies_relation[]" class="form-control form-control-solid h-auto py-7 px-6 rounded-lg font-size-h6 tagsinput-field" data-role="tagsinput" multiple>
                <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($term->term_taxonomy_id); ?>" <?php if(in_array($term->term_taxonomy_id,$selected_terms->pluck('term_taxonomy_id')->toArray())): ?> selected <?php endif; ?>><?php echo e($term->term->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button type="button" class="btn btn-success add_new_term" data-taxonomy-type="<?php echo e($taxonomy); ?>">
                Add New
            </button>
        </div>


    </div>
</div>

<?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/supplier/products/components/product_form/attribute_selector.blade.php ENDPATH**/ ?>