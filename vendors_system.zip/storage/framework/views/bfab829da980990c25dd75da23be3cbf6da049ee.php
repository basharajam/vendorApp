<form class="form" method="POST" action="<?php echo e(route('login')); ?>" id="kt_login_signin_form">
    <?php echo csrf_field(); ?>
    <!--begin::Title-->
    <div class="text-center pb-8">
        <h2 class="font-weight-bolder text-dark font-size-h2 font-size-h1-lg">تسجيل دخول</h2>
        <span class="text-muted font-weight-bold font-size-h4">أو
        <a href="<?php echo e(route('supplier_registeration_view')); ?>" class="text-primary font-weight-bolder" >إنشاء حساب جديد</a></span>
    </div>
    <!--end::Title-->
    <!--begin::Form group-->
    <div class="form-group">
        <label class="font-size-h6 font-weight-bolder text-dark">البردي الالكتروني</label>
        <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
               type="text"
               name="email"
               value="<?php echo e(old('email')); ?>"
               required
               autocomplete="off" />
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="fv-plugins-message-container">
            <div  class="fv-help-block"><?php echo e($message); ?></div>
        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <!--end::Form group-->
    <!--begin::Form group-->
    <div class="form-group">
        <div class="d-flex justify-content-between mt-n5">
            <label class="font-size-h6 font-weight-bolder text-dark pt-5">كلمة المرور</label>
            <a href="javascript:;" class="text-primary font-size-h6 font-weight-bolder text-hover-primary pt-5" id="kt_login_forgot">نسيت كلمة المرور ?</a>
        </div>
        <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg" type="password" name="password" required autocomplete="off" />
    </div>
    <!--end::Form group-->
    <!--begin::Action-->
    <div class="text-center pt-2">
        <button id="kt_login_signin_submit" class="btn btn-dark font-weight-bolder font-size-h6 px-8 py-4 my-3">تسجيل الدخول</button>
    </div>
    <!--end::Action-->
</form>
<?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/auth/components/login_form.blade.php ENDPATH**/ ?>