<div class="modal fade " id="EditModal" tabindex="-1" role="dialog" aria-labelledby="editTaxonomy" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLable">تعديل</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               <form method="POST" action="<?php echo e(route('supplier.taxonomies.update',$taxonomy->term_taxonomy_id)); ?>">
                <?php echo $__env->make('supplier.taxonomies.components.taxonomy_form',['taxonomy'=>$taxonomy], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
               </form>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/supplier/taxonomies/components/edit_modal.blade.php ENDPATH**/ ?>