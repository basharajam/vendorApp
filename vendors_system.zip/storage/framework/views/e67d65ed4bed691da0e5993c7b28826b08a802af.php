<table id="ProductsTable" class="table" style="direction:rtl;text-align:right">
    <thead class="thead-light">
        <tr>
            <th class="">
                <span>المنتج</span>
                <div class="font-weight-bold text-muted">Product </div>
            </th>
            <th class="">
                <span>فئات المنتج</span>
                <div class="font-weight-bold text-muted">Product Categories</div>
            </th>
            <th class="">
                <span>السعر</span>
                <div class="font-weight-bold text-muted">Price</div>
            </th>
            <th class="">
                <span>السعر بعد الحسم</span>
                <div class="font-weight-bold text-muted">Price After Discount</div>
            </th>
            <th class="">
                <span>الحجم</span>
                <div class="font-weight-bold text-muted">Size</div>
            </th>
             <th class="">
                <span>الوزن</span>
                <div class="font-weight-bold text-muted">Weight</div>
            </th>
              <th class="">
                <span>CMB</span>
                <div class="font-weight-bold text-muted">CBM</div>
            </th>
            <th>.</th>
        </tr>
    </thead>
    <tbody style="direction:rtl;text-align:right">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $meta = $product->meta;
            ?>
            <tr id="<?php echo e($product->ID); ?>">
                <td class="datatable-cell">
                    <span style="width: 250px;">
                        <div class="d-flex align-items-center">
                            <div style="padding-left:10px;" class="symbol symbol-50   symbol-sm symbol-light-danger">
                                <span class="symbol-label font-size-p" style="background-image:url(/path/to/image)"></span>
                            </div>
                            <div class="ml-3">
                                <div class="text-dark-75 font-weight-bolder font-size-lg mb-0">
                                       <?php echo e($product->post_title); ?>

                                </div>
                                <span  class="text-muted font-weight-bold text-hover-primary ">
                                    <?php if($meta && count($meta)>0 && array_key_exists('supplier_name',$meta)): ?>
                                    <?php echo e($meta['supplier_name']); ?>

                                 <?php endif; ?>
                                </span>
                            </div>
                        </div>
                    </span>
                </td>

                <td class="datatable-cell-sorted datatable-cell">
                    <span>
                        <div class="font-weight-bolder font-size-lg mb-0">
                             <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <span class="m-2 label font-weight-bold label-lg label-light-default label-inline">
                                <?php echo e($category->term->name); ?>

                            </span>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </span>
                </td>
                <td class="datatable-cell-sorted datatable-cell">
                    <span>
                        <div class="font-weight-bolder font-size-lg mb-0">
                            <?php if($meta && count($meta)>0 && array_key_exists('_regular_price',$meta)): ?>
                            <?php echo e($meta['_regular_price']); ?>

                         <?php endif; ?>
                        </div>
                    </span>
                </td>
                <td class="datatable-cell-sorted datatable-cell">
                    <span>
                        <div class="font-weight-bolder font-size-lg mb-0">
                            <?php if($meta && count($meta)>0 && array_key_exists('_sale_price',$meta)): ?>
                            <?php echo e($meta['_sale_price']); ?>

                         <?php endif; ?>
                        </div>
                    </span>
                </td>
                <td class="datatable-cell-sorted datatable-cell">
                    <span>
                        <div class="font-weight-bolder font-size-lg mb-0">
                            <?php if($meta && count($meta)>0 && array_key_exists('size',$meta)): ?>
                            <?php echo e($meta['size']); ?>

                         <?php endif; ?>
                        </div>
                    </span>
                </td>
                <td class="datatable-cell-sorted datatable-cell">
                    <span>
                        <div class="font-weight-bolder font-size-lg mb-0">
                            <?php if($meta && count($meta)>0 && array_key_exists('_weight',$meta)): ?>
                            <?php echo e($meta['_weight']); ?>

                         <?php endif; ?>
                        </div>
                    </span>
                </td>
                <td class="datatable-cell-sorted datatable-cell">
                    <span>
                        <div class="font-weight-bolder font-size-lg mb-0">
                            <?php if($meta && count($meta)>0 && array_key_exists('cbm_single',$meta)): ?>
                            <?php echo e($meta['cbm_single']); ?>

                         <?php endif; ?>
                        </div>
                    </span>
                </td>
                <td class="datatable-cell-sorted datatable-cell">
                    <a id="<?php echo e($product->ID); ?>" class="kt-nav__link mr-5 delete" data-action-name="<?php echo e(route('supplier.products.delete',$product->ID)); ?>" href="javascript:;"  ><i class="kt-nav__link-icon flaticon2-trash "></i></a>
                    <a class="kt-nav__link"  href="<?php echo e(route('supplier.products.create',$product->ID)); ?>"  ><i class="kt-nav__link-icon color-primary flaticon-edit-1 "></i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
    $('#ProductsTable').DataTable();
} );
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\WORK\AlYaman\vendors_system\resources\views/supplier/products/components/products_table.blade.php ENDPATH**/ ?>