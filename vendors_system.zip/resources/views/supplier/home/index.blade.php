@extends('layouts.app')

@section('content')
<h3>Supplier Dashboard</h3>
@endsection
