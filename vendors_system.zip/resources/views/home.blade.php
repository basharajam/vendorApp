@extends('layouts.app')
@section('content')
<h3>Hi</h3>
@endsection
