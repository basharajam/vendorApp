<div>
    <div class="kt-header__top ">
        <div class="kt-container kt-container--fluid ">
            <!-- begin:: Brand -->
            <div class="kt-header__brand   kt-grid__item" id="kt_header_brand">
                <div class="kt-header__brand-nav">
                   <img src="/images/logo.png">
                </div>
            </div>
            <!-- end:: Brand -->
            <!-- begin:: Header Topbar -->
            <div class="kt-header__topbar">
                <x-layout.header-user-bar/>
            </div>
            <!-- end:: Header Topbar -->
        </div>
    </div>
</div>
