<div id="kt_header" class="kt-header kt-grid__item kt-header--fixed " data-ktheader-minimize="on">
    <x-layout.header-top-bar/>
    <x-layout.header-menu/>
</div>
