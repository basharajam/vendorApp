<?php
namespace App\Constants;

class ProductTypes  {

    CONST SIMPLE = 'simple';
    CONST VARIABLE = 'variable';

    CONST ALL_TYPES=[
        self::SIMPLE,
        self::SIMPLE,
    ];


}
