<?php
namespace App\Constants;

class UserRoles  {

    CONST SUPPLIER = 'supplier';
    CONST SUPPLIERMANAGER = 'supplier_manager';

    CONST ALL_ROLES=[
        self::SUPPLIER,
        self::SUPPLIER,
    ];


}
