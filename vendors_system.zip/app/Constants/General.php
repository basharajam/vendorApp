<?php
namespace App\Constants;

class General  {

    CONST URL = 'https://alyamanlive.com';

}
