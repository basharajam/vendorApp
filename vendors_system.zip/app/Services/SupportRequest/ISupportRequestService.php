<?php


namespace App\Services\SupportRequest;


use App\Services\Contracts\IBaseService;

/**
 * Interface ISupportRequestService
 * @package App\Services\SupportRequest
 */
interface ISupportRequestService extends IBaseService
{

}
