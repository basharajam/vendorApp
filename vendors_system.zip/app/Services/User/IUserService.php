<?php


namespace App\Services\User;


use App\Services\Contracts\IBaseService;

/**
 * Interface IUserService
 * @package App\Services\User
 */
interface IUserService extends IBaseService
{

}
