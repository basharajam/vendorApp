<?php


namespace App\Services\Supplier;


use App\Services\Contracts\IBaseService;

/**
 * Interface ISupplierService
 * @package App\Services\Supplier
 */
interface ISupplierService extends IBaseService
{

}
