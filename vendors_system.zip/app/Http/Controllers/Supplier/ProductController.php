<?php

namespace App\Http\Controllers\Supplier;

use App\Http\Controllers\Controller;
use App\Http\Requests\Supplier\StoreProductRequest;
use Illuminate\Http\Request;
use App\Models\WP\TermTaxonomy;
use App\Services\Post\IPostService;
use App\Services\TermTaxonomy\ITermTaxonomyService;
use Symfony\Component\HttpKernel\Event\RequestEvent;

class ProductController extends Controller
{
    private $post_service,$term_taxonomy_service;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(IPostService  $post_service,ITermTaxonomyService $term_taxonomy_service)
    {
        $this->middleware('auth');
        $this->post_service=$post_service;
        $this->term_taxonomy_service = $term_taxonomy_service;
    }

    public function index(){
        $products = $this->post_service->get_products_for_supplier(\Auth::user()->wordpress_user->ID);

        return view('supplier.products.index')
                ->with('products',$products);
    }

    public function addedit($id=0){

        $categories = $this->term_taxonomy_service->categories();
        $attributes =$this->term_taxonomy_service->attributes();
        $product = null;
        if($id!=0)
        {
            $product = $this->post_service->find_product_for_supplier($id,\Auth::user()->wordpress_user->ID);
        }
        //dd($product->product_attributes);
        return view('supplier.products.addedit')
                ->with('categories',$categories)
                ->with('attributes',$attributes)
                ->with('product',$product);
    }

    public function store(Request $request){
        $product = null;
        switch($request->request_type){
            case "product":
                if($request->post_id == 0)
                    $product =  $this->post_service->store_product($request);
                else{
                    $product =  $this->post_service->update_product($request,$request->post_id);
                }
            break;
            case "general":
                $product =  $this->post_service->store_product_general($request,$request->post_id);
            break;
            case "inventory":
                $product =  $this->post_service->store_product_inventory($request,$request->post_id);
            break;
            case "shipping":
                $product =  $this->post_service->store_product_shipping($request,$request->post_id);
            break;
            case "attributes":
                $product =  $this->post_service->store_product_attributes($request,$request->post_id);
            break;
            case "categories":
                $product =  $this->post_service->store_product_categories($request,$request->post_id);
            break;
        }
        //TOOD Add toaster
        return redirect()->route('supplier.products.create',$product->ID ?? $request->post_id  ??  0);
    }

    public function delete(int $id){
        return $this->post_service->delete($id);
    }

    public function getForm($type){
        $categories = TermTaxonomy::categories()->get();
        switch($type){
            case \ProductTypes::SIMPLE:
                $product =null;
                return view('supplier.products.components.simple_product',compact('categories','product'));
            break;
            case \ProductTypes::VARIABLE:
                return view('supplier.products.components.variable_product');
            break;
        }
    }
    public function getAttributeSelector(Request $request){
        $taxonomy =TermTaxonomy::where('term_taxonomy_id',$request->term_taxonomy_id)->first();
       return view('supplier.products.components.product_form.attribute_selector')->with('taxonomy',$taxonomy);
    }

    public function getTaxonomyTerms(Request $request){
        $taxonomy =TermTaxonomy::where('term_taxonomy_id',$request->term_taxonomy_id)->first();
        return $taxonomy->terms;
    }
    public function storeVariation(Request $request){
        return $request;
    }
}
